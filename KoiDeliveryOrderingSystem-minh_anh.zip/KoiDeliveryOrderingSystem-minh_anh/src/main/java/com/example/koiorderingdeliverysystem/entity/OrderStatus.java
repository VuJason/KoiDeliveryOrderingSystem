package com.example.koiorderingdeliverysystem.entity;

public enum OrderStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    CANCELED
}
