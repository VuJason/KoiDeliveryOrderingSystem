package com.example.koiorderingdeliverysystem.repository;

import com.example.koiorderingdeliverysystem.entity.KoiService;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KoiServiceRepository extends JpaRepository<KoiService, String> {
}
