package com.example.koiorderingdeliverysystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class KoiorderingdeliverysystemApplication {

    public static void main(String[] args)
    {
        SpringApplication.run(KoiorderingdeliverysystemApplication.class, args);
    }

}
