package com.example.koiorderingdeliverysystem.entity;

public class KoiFish {
}
